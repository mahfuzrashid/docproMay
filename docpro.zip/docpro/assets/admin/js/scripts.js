/**
 * Admin Scripts
 */

(function ($, window, document, pluginObject) {
    "use strict";

    // let docproReviewSection = $('.docpro-review-section');
    //
    // $(function () {
    //     if (docproReviewSection.length) {
    //         $('html, body').animate({
    //             scrollTop: docproReviewSection.offset().top - 30
    //         }, 1500);
    //         return false;
    //     }
    // });

})(jQuery, window, document, docpro);







