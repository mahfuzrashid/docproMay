<?php
/**
 * Class Functions
 *
 * @author Pluginbazar
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'DOCPRO_Functions' ) ) {
	/**
	 * Class DOCPRO_Functions
	 *
	 * @property PB_Settings $pbSettings;
	 * @property DOCPRO_Meta_boxes $metaBoxes;
	 * @property DOCPRO_Shortcodes $shortCodes;
	 */
	class DOCPRO_Functions {


		/**
		 * Return valid profile/user types
		 *
		 * @return mixed|void
		 */
		function get_profile_types() {
			return apply_filters( 'docpro_filters_profile_types', array(
				'doctor'  => esc_html__( 'Doctor', 'docpro' ),
				'clinic'  => esc_html__( 'Clinic', 'docpro' ),
				'patient' => esc_html__( 'Patient', 'docpro' ),
			) );
		}

		/**
		 * Return departments as array
		 *
		 * @return array
		 */
		function get_departments() {
			$_departments = docpro()->get_option( 'docpro_departments' );
			$_departments = empty( $_departments ) || ! is_array( $_departments ) ? array() : $_departments;
			$departments  = array();

			foreach ( $_departments as $department ) {
				if ( ! empty( $department_id = docpro()->get_args_option( 'id', '', $department ) ) ) {
					$departments[ $department_id ] = docpro()->get_args_option( 'name', '', $department );
				}
			}

			return $departments;
		}


		/**
		 * Return of all query vars
		 *
		 * @return mixed|void
		 */
		function get_query_vars() {
			$query_vars = array(
				'doctor'  => EP_ROOT | EP_PAGES,
				'clinic'  => EP_ROOT | EP_PAGES,
				'patient' => EP_ROOT | EP_PAGES,
				'content' => EP_ROOT | EP_PAGES,
			);

			return apply_filters( 'docpro_query_vars', $query_vars );
		}


		/**
		 * Return booking product ID
		 *
		 * @return mixed|string|void
		 */
		function get_booking_product_id() {
			return (int) $this->get_option( 'docpro_booking_product', 0 );
		}


		/**
		 * Return users per page
		 *
		 * @param array $args
		 *
		 * @return mixed|void
		 */
		function get_users_per_page( $args = array() ) {

			switch ( docpro()->get_args_option( 'role', 'doctor', $args ) ) {
				case 'clinic' :
					$option_key = 'docpro_clinic_items_per_page';
					break;

				default :
					$option_key = 'docpro_doctors_items_per_page';
					break;
			}

			return apply_filters( 'docpro_filters_users_per_page', $this->get_option( $option_key, 10 ) );
		}


		/**
		 * Return doctors list
		 *
		 * @param array $args
		 *
		 * @return array
		 */
		function get_doctors_list( $args = array() ) {
			$defaults = array(
				'role' => 'doctor',
			);
			$doctors  = array();
			$_doctors = get_users( wp_parse_args( $args, $defaults ) );

			foreach ( $_doctors as $doctor ) {
				if ( $doctor instanceof WP_User ) {
					$doctors[ $doctor->ID ] = $doctor->display_name;
				}
			}

			return $doctors;
		}


		function get_post_type_supports() {
//			'title', 'editor', 'comments', 'revisions', 'trackbacks', 'author', 'excerpt', 'page-attributes', 'thumbnail', 'custom-fields', and 'post-formats'
		}


		/**
		 * Return page id
		 *
		 * @param string $page_for
		 *
		 * @return int
		 */
		function get_page_id( $page_for = '' ) {
			$page_id = 0;

			switch ( $page_for ) {
				case 'profiles' :
					$page_id = get_option( 'docpro_page_profiles' );


			}

			return (int) $page_id;
		}


		/**
		 * Check a page and return boolean
		 *
		 * @param string $checking_for
		 * @param false $page_id
		 *
		 * @return bool
		 */
		function is_page( $checking_for = '', $page_id = false ) {

			$page_id = ! $page_id || empty( $page_id ) ? get_the_ID() : $page_id;
			$is_page = false;

			if ( empty( $checking_for ) || ! $page_id || empty( $page_id ) ) {
				return false;
			}

			switch ( $checking_for ) {
				case 'profiles' :
					if ( $page_id == $this->get_option( 'docpro_page_profiles' ) ) {
						$is_page = true;
					}
					break;

				case 'doctor' :
					if ( get_query_var( 'pagename' ) == 'profiles' && ! empty( get_query_var( 'doctor' ) ) ) {
						$is_page = true;
					}
					break;

				case 'patient' :
					if ( get_query_var( 'pagename' ) == 'profiles' && ! empty( get_query_var( 'patient' ) ) ) {
						$is_page = true;
					}
					break;

				case 'clinic' :
					if ( get_query_var( 'pagename' ) == 'profiles' && ! empty( get_query_var( 'clinic' ) ) ) {
						$is_page = true;
					}
					break;
			}


			return $is_page;
		}


		/**
		 * Return all countries and states as group
		 *
		 * @return mixed|void
		 */
		function get_all_countries_states() {

			$countries        = $this->get_countries();
			$countries_states = array();

			foreach ( array_filter( $this->get_states() ) as $country_code => $states ) {

				if ( ! is_array( $states ) ) {
					continue;
				}

				$country_label  = $this->get_args_option( $country_code, '', $countries );
				$single_country = array();

				foreach ( $states as $state_code => $state_label ) {
					$single_country[ $country_code . '#' . $state_code ] = $country_label . ' - ' . $state_label;
				}

				$countries_states[ $country_label ] = $single_country;
			}

			return apply_filters( 'docpro_filters_all_countries_states', $countries_states );
		}


		/**
		 * Return states with country code
		 *
		 * @return mixed
		 */
		function get_states() {
			return include DOCPRO_PLUGIN_DIR . 'i18n/states.php';
		}


		/**
		 * Return countries as array
		 *
		 * @return array
		 */
		function get_countries() {
			return include DOCPRO_PLUGIN_DIR . 'i18n/countries.php';
		}


		/**
		 * Return location capabilities as array
		 *
		 * @return mixed|void
		 */
		function get_location_capabilities() {
			return apply_filters( 'docpro_filters_location_capabilities', array(
				'edit_post'              => 'edit_location',
				'read_post'              => 'read_location',
				'delete_post'            => 'delete_location',
				'edit_posts'             => 'edit_locations',
				'edit_others_posts'      => 'edit_others_locations',
				'edit_published_posts'   => 'edit_published_locations',
				'publish_posts'          => 'publish_locations',
				'delete_posts'           => 'delete_locations',
				'delete_others_posts'    => 'delete_others_locations',
				'delete_published_posts' => 'delete_published_locations',
				'delete_private_posts'   => 'delete_private_locations',
				'edit_private_posts'     => 'edit_private_locations',
				'read_private_posts'     => 'read_private_locations',
			) );
		}


		/**
		 * Return plugin settings page as array
		 *
		 * @return mixed|void
		 */
		function get_plugin_settings() {

			$page_options  = array( '' => esc_html__( 'Select page', 'docpro' ) ) + docpro()->pbSettings->generate_args_from_string( 'PAGES', array() );
			$contact_forms = array( '' => esc_html__( 'Select form', 'docpro' ) ) + docpro()->pbSettings->generate_args_from_string( 'POSTS_%wpcf7_contact_form%', array() );

			// Settings Section
			$sections[] = array(
				'id'     => 'docpro_options',
				'title'  => esc_html__( 'Settings', 'docpro' ),
				'fields' => array(
					array(
						'id'          => 'docpro_gmap_api',
						'title'       => esc_html__( 'Google Map API Key', 'docpro' ),
						'desc'        => esc_html__( 'Enter your google map api key here  AIzaSyD5dHX3A9YYi2gK4AgkcusPOuOn4pIkj6Kg', 'docpro' ),
						'default' => esc_attr( 'AIzaSyD5dHX3A9YYi2gK4AgkcusPOuOn4pIkj6Kg' ),
						'type'        => 'text',
					),
					array(
						'id'          => 'docpro_map_zoom',
						'title'       => esc_html__( 'Google Map Zoom', 'docpro' ),
						'desc'        => esc_html__( 'Enter zoom value for Google Map. Default: 5', 'docpro' ),
						'default' => esc_attr( '10' ),
						'type'        => 'number',
					),
					array(
						'id'      => 'docpro_review_form_page',
						'type'    => 'select',
						'title'   => esc_html__( 'Review form page', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'      => 'docpro_reg_page',
						'type'    => 'select',
						'title'   => esc_html__( 'Registration page', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'           => 'docpro_departments',
						'type'         => 'repeater',
						'title'        => esc_html__( 'Departments', 'docpro' ),
						'button_title' => esc_html__( 'Add Department', 'docpro' ),
						'fields'       => array(
							array(
								'id'          => 'id',
								'type'        => 'text',
								'title'       => esc_html__( 'ID', 'docpro' ),
								'default' => esc_html__( 'Cardiology', 'docpro' ),
							),
							array(
								'id'          => 'name',
								'type'        => 'text',
								'title'       => esc_html__( 'Name', 'docpro' ),
								'default' => esc_html__( 'Cardiology', 'docpro' ),
							),
						),
						'default'      => array( '' ),
					),
				),
			);
				// Doctors Settings Section
			$sections[] = array(
				'id'     => 'docpro_settings_shortcodes',
				'title'  => esc_html__( 'Shortcodes Settings', 'docpro' ),
				'fields' => array(
					
					array(
						'id'          => 'docpro_doctor_shortcode',
						'type'        => 'button_set',
					   'title'        => esc_html__( 'Doctor Page Shortcode Enter', 'docpro' ),
						'desc'       => esc_html__( '[doctors] ', 'docpro' ),
						'default' => esc_html__( '[doctors]', 'docpro' ),
					),
					
						array(
						'id'          => 'docpro_doctorsingle_shortcode',
						'type'        => 'button_set',
					   'title'        => esc_html__( 'Single Page Shortcode Enter', 'docpro' ),
						'desc'       => esc_html__( '[docpro-profiles] ', 'docpro' ),
						'default' => esc_html__( '[docpro-profiles]', 'docpro' ),
					),
	array(
						'id'          => 'docpro_clinicsingle_shortcode',
						'type'        => 'button_set',
						'title'        => esc_html__( 'Clinic  Shortcode Enter', 'docpro' ),
						'desc'       => esc_html__( '[clinics] ', 'docpro' ),
						'default' => esc_html__( '[clinics]', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_big_shortcode',
						'type'        => 'button_set',
						'title'        => esc_html__( 'Clinic Map View Page Shortcode Enter', 'docpro' ),
						'desc'       => esc_html__( '[clinics view="large-map"]', 'docpro' ),
						'default' => esc_html__( '[clinics view="large-map"]', 'docpro' ),
					),
			
				
					
					array(
						'id'          => 'docpro_review_form',
						'type'        => 'button_set',
						'title'        => esc_html__( 'Review Form', 'docpro' ),
						'desc'       => esc_html__( '[review-form]', 'docpro' ),
						'default' => esc_html__( '[review-form]', 'docpro' ),
					),
						array(
						'id'          => 'docpro_reg_form',
						'type'        => 'button_set',
						'title'        => esc_html__( 'Registration Form', 'docpro' ),
						'desc'       => esc_html__( '[docpro-registration]', 'docpro' ),
						'default' => esc_html__( '[docpro-registration]', 'docpro' ),
					),
					
						array(
						'id'          => 'docpro_reg_form',
						'type'        => 'button_set',
						'title'        => esc_html__( 'Dashbord ', 'docpro' ),
						'desc'       => esc_html__( '[docpro-dashboard]', 'docpro' ),
						'placeholder' => esc_html__( '[docpro-dashboard]', 'docpro' ),
					),
				
					
				)
			);

			// Settings - Booking Section
			$sections[] = array(
//				'parent' => 'docpro_options',
				'title'  => esc_html__( 'Booking Options', 'docpro' ),
				'fields' => array(
					array(
						'id'    => 'docpro_enable_payment',
						'title' => esc_html__( 'Enable Payment Receive', 'docpro' ),
						'desc'  => esc_html__( 'You must install and activate WooCommerce to get this support.', 'docpro' ),
						'type'  => 'switcher',
					),
					array(
						'id'      => 'docpro_dashboard_page',
						'type'    => 'select',
						'title'   => esc_html__( 'Dashboard page', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'         => 'docpro_booking_product',
						'title'      => esc_html__( 'Select Booking Product', 'docpro' ),
						'desc'       => esc_html__( 'You must select a booking product to take payment.', 'docpro' ),
						'type'       => 'select',
						'options'    => 'posts',
						'chosen'     => true,
						'query_args' => array(
							'post_type' => 'product',
						),
					),
				),
			);


			// Doctors Settings Section
			$sections[] = array(
				'id'     => 'docpro_settings_doctors',
				'title'  => esc_html__( 'Doctors Settings', 'docpro' ),
				'fields' => array(
					array(
						'id'      => 'docpro_doctors_page',
						'type'    => 'select',
						'title'   => esc_html__( 'Doctors page (General View)', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'      => 'docpro_doctors_page_map',
						'type'    => 'select',
						'title'   => esc_html__( 'Doctors page (Map View)', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'          => 'docpro_doctors_items_per_page',
						'type'        => 'number',
						'title'       => esc_html__( 'Items per page', 'docpro' ),
						'default' => 10,
					),
					
				
					
				)
			);


			// Clinic Settings Section
			$sections[] = array(
				'id'     => 'docpro_settings_clinic',
				'title'  => esc_html__( 'Clinic Settings', 'docpro' ),
				'fields' => array(
					array(
						'id'      => 'docpro_clinic_page',
						'type'    => 'select',
						'title'   => esc_html__( 'Clinic page (General View)', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'      => 'docpro_clinic_page_map',
						'type'    => 'select',
						'title'   => esc_html__( 'Clinic page (Map View)', 'docpro' ),
						'options' => $page_options,
					),
					array(
						'id'          => 'docpro_clinic_items_per_page',
						'type'        => 'number',
						'title'       => esc_html__( 'Items per page', 'docpro' ),
						'default' => 10,
					),
					array(
						'id'      => 'docpro_clinic_contact_form',
						'type'    => 'select',
						'title'   => esc_html__( 'Clinic Contact Form', 'docpro' ),
						'options' => $contact_forms,
					),
				)
			);
			
			// Text Settings Section
			$sections[] = array(
				'id'     => 'docpro_settings_text',
				'title'  => esc_html__( 'Doctors Text Settings', 'docpro' ),
				'fields' => array(
				
					array(
						'id'          => 'docpro_doctors_tab_overview',
						'type'        => 'text',
						'title'       => esc_html__( 'Tab Overview Title', 'docpro' ),
						'default' => esc_html__( 'Overview', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_tab_experiences',
						'type'        => 'text',
						'title'       => esc_html__( 'Tab Experiance Title', 'docpro' ),
						'default' => esc_html__( 'Experiance', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_tab_reviews',
						'type'        => 'text',
						'title'       => esc_html__( 'Tab Review Title', 'docpro' ),
						'default' => esc_html__( 'Review', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_tab_location',
						'type'        => 'text',
						'title'       => esc_html__( 'Tab Locations Title', 'docpro' ),
						'default' => esc_html__( 'Locations', 'docpro' ),
					),
					
					array(
						'id'          => 'docpro_doctors_onboard_doctors',
						'type'        => 'text',
						'title'       => esc_html__( 'OnBoard Doctors', 'docpro' ),
						'default' => esc_html__( 'OnBoard Doctors', 'docpro' ),
					),
					array(
						'id'          => 'docpro_doctors_text_about',
						'type'        => 'text',
						'title'       => esc_html__( 'About Doctor', 'docpro' ),
						'default' => esc_html__( 'About', 'docpro' ),
					),
					array(
						'id'          => 'docpro_doctors_text_education',
						'type'        => 'text',
						'title'       => esc_html__( ' Doctor Education', 'docpro' ),
						'default' => esc_html__( 'Educations', 'docpro' ),
					),
					array(
						'id'          => 'docpro_doctors_text_specialities',
						'type'        => 'text',
						'title'       => esc_html__( ' Doctor Specialities', 'docpro' ),
						'default' => esc_html__( 'Specialities', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_text_specialities2',
						'type'        => 'text',
						'title'       => esc_html__( ' Has Specialities', 'docpro' ),
						'default' => esc_html__( 'Has Specialities on Bellow Feilds', 'docpro' ),
					),
				   array(
						'id'          => 'docpro_doctors_text_services',
						'type'        => 'text',
						'title'       => esc_html__( 'Offered Services', 'docpro' ),
						'default' => esc_html__( 'Offered Services', 'docpro' ),
					),
					
					  array(
						'id'          => 'docpro_doctors_text_services_tab',
						'type'        => 'text',
						'title'       => esc_html__( 'Table Top Text Services', 'docpro' ),
						'default' => esc_html__( 'Services', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_text_price_tab',
						'type'        => 'text',
						'title'       => esc_html__( 'Table Top Text Price', 'docpro' ),
						'default' => esc_html__( 'Price', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_text_awards',
						'type'        => 'text',
						'title'       => esc_html__( 'Awards Text ', 'docpro' ),
						'default' => esc_html__( 'Awards', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_text_experience',
						'type'        => 'text',
						'title'       => esc_html__( 'Experience Text ', 'docpro' ),
						'default' => esc_html__( 'Experience', 'docpro' ),
					),
						array(
						'id'          => 'docpro_doctors_text_skills',
						'type'        => 'text',
						'title'       => esc_html__( 'Skills Text ', 'docpro' ),
						'default' => esc_html__( 'Skills', 'docpro' ),
					),
					array(
						'id'          => 'docpro_doctors_text_skills_in',
						'type'        => 'text',
						'title'       => esc_html__( 'Expert in Text ', 'docpro' ),
						'default' => esc_html__( 'Expert in', 'docpro' ),
					),
					array(
						'id'          => 'docpro_doctors_text_reviews',
						'type'        => 'text',
						'title'       => esc_html__( 'Doctor Review Title ', 'docpro' ),
						'default' => esc_html__( 'Review', 'docpro' ),
					),
					
						array(
						'id'          => 'docpro_doctors_text_reviews_bbtn',
						'type'        => 'text',
						'title'       => esc_html__( ' Review Button Title ', 'docpro' ),
						'default' => esc_html__( 'Submit Review', 'docpro' ),
					),
					
				  array(
						'id'          => 'docpro_doctors_text_reviews_based',
						'type'        => 'text',
						'title'       => esc_html__( ' Based on Text ', 'docpro' ),
						'default' => esc_html__( 'Based on totla Revews', 'docpro' ),
					),
					
					 array(
						'id'          => 'docpro_doctors_text_locations',
						'type'        => 'text',
						'title'       => esc_html__( ' Locatin Text ', 'docpro' ),
						'default' => esc_html__( 'Our Locations', 'docpro' ),
					),
					 array(
						'id'          => 'docpro_doctors_text_chamber',
						'type'        => 'text',
						'title'       => esc_html__( ' Chamber Locatin Text ', 'docpro' ),
						'default' => esc_html__( 'Chamber  Locations', 'docpro' ),
					),
					 array(
						'id'          => 'docpro_doctors_text_booking',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Booking Text ', 'docpro' ),
						'default' => esc_html__( 'Book Appointment', 'docpro' ),
					),
						 array(
						'id'          => 'docpro_doctors_text_choose',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Choose Text ', 'docpro' ),
						'default' => esc_html__( 'Choose Services', 'docpro' ),
					),
						 array(
						'id'          => 'docpro_doctors_text_error',
						'type'        => 'text',
						'title'       => esc_html__( 'Service Error Text ', 'docpro' ),
						'default' => esc_html__( 'Services Not found', 'docpro' ),
					),
						 array(
						'id'          => 'docpro_doctors_text_book_bttn',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Booking Text ', 'docpro' ),
						'default' => esc_html__( 'Book Now', 'docpro' ),
					),
					
					 array(
						'id'          => 'docpro_doctor_text_contact',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Title  ', 'docpro' ),
						'default' => esc_html__( 'Contact Us', 'docpro' ),
					),
					array(
						'id'          => 'docpro_doctor_contact_form7',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Form 7  ', 'docpro' ),
						'placeholder' => esc_html__( '[contact-form-7 id="67" title="Clinic Contact Form"] ', 'docpro' ),
					),
				
				
				)
			);
			
			// Text Settings Section
			$sections[] = array(
				'id'     => 'docpro_settings_text_clinic',
				'title'  => esc_html__( 'Clinic Text Settings', 'docpro' ),
				'fields' => array(
				
					array(
						'id'          => 'docpro_clinic_text_about',
						'type'        => 'text',
						'title'       => esc_html__( 'About Clinic', 'docpro' ),
						'default' => esc_html__( 'About', 'docpro' ),
					),
				
					array(
						'id'          => 'docpro_clinic_text_specialities',
						'type'        => 'text',
						'title'       => esc_html__( ' Clinic Specialities', 'docpro' ),
						'default' => esc_html__( 'Specialities', 'docpro' ),
					),
						array(
						'id'          => 'docpro_clinic_text_specialities2',
						'type'        => 'text',
						'title'       => esc_html__( ' Has Specialities', 'docpro' ),
						'default' => esc_html__( 'Has Specialities on Bellow Feilds', 'docpro' ),
					),
				   array(
						'id'          => 'docpro_clinic_text_services',
						'type'        => 'text',
						'title'       => esc_html__( 'Offered Services', 'docpro' ),
						'default' => esc_html__( 'Offered Services', 'docpro' ),
					),
					
					  array(
						'id'          => 'docpro_clinic_text_services_tab',
						'type'        => 'text',
						'title'       => esc_html__( 'Table Top Text Services', 'docpro' ),
						'default' => esc_html__( 'Services', 'docpro' ),
					),
						array(
						'id'          => 'docpro_clinic_text_price_tab',
						'type'        => 'text',
						'title'       => esc_html__( 'Table Top Text Price', 'docpro' ),
						'default' => esc_html__( 'Price', 'docpro' ),
					),
						array(
						'id'          => 'docpro_clinic_text_awards',
						'type'        => 'text',
						'title'       => esc_html__( 'Awards Text ', 'docpro' ),
						'default' => esc_html__( 'Awards', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_text_gallery',
						'type'        => 'text',
						'title'       => esc_html__( 'Gallery Text ', 'docpro' ),
						'default' => esc_html__( 'Gallery', 'docpro' ),
					),
					
					
					
						array(
						'id'          => 'docpro_clinic_text_experience',
						'type'        => 'text',
						'title'       => esc_html__( 'Experience Text ', 'docpro' ),
						'default' => esc_html__( 'Experience', 'docpro' ),
					),
						array(
						'id'          => 'docpro_clinic_text_skills',
						'type'        => 'text',
						'title'       => esc_html__( 'Skills Text ', 'docpro' ),
						'default' => esc_html__( 'Skills', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_text_skills_in',
						'type'        => 'text',
						'title'       => esc_html__( 'Expert in Text ', 'docpro' ),
						'default' => esc_html__( 'Expert in', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_text_reviews',
						'type'        => 'text',
						'title'       => esc_html__( 'Doctor Review Title ', 'docpro' ),
						'default' => esc_html__( 'Review', 'docpro' ),
					),
					
					array(
						'id'          => 'docpro_clinic_text_reviews_bbtn',
						'type'        => 'text',
						'title'       => esc_html__( ' Review Button Title ', 'docpro' ),
						'default' => esc_html__( 'Submit Review', 'docpro' ),
					),
					
				   array(
						'id'          => 'docpro_clinic_text_reviews_based',
						'type'        => 'text',
						'title'       => esc_html__( ' Based on Text ', 'docpro' ),
						'default' => esc_html__( 'Based on totla Revews', 'docpro' ),
					),
					
				  array(
						'id'          => 'docpro_clinic_text_locations',
						'type'        => 'text',
						'title'       => esc_html__( ' Locatin Text ', 'docpro' ),
						'default' => esc_html__( 'Our Locations', 'docpro' ),
					),
				   array(
						'id'          => 'docpro_clinic_text_chamber',
						'type'        => 'text',
						'title'       => esc_html__( ' Chamber Locatin Text ', 'docpro' ),
						'default' => esc_html__( 'Chamber  Locations', 'docpro' ),
					),
					
					 array(
						'id'          => 'docpro_clinic_text_onboard',
						'type'        => 'text',
						'title'       => esc_html__( ' On Board  Text ', 'docpro' ),
						'default' => esc_html__( 'On Board Doctor', 'docpro' ),
					),
					
					 array(
						'id'          => 'docpro_clinic_text_contact',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Title  ', 'docpro' ),
						'default' => esc_html__( 'Contact Us', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_contact_form7',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Form 7  ', 'docpro' ),
						'placeholder' => esc_html__( '[contact-form-7 id="67" title="Clinic Contact Form"] ', 'docpro' ),
					),
					
					array(
						'id'          => 'docpro_clinic_contact_info',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info Title ', 'docpro' ),
						'default' => esc_html__( 'Contact Info', 'docpro' ),
					),
					
					array(
						'id'          => 'docpro_clinic_contact_info_location',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info Location ', 'docpro' ),
						'default' => esc_html__( 'Location', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_contact_info_phone',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info Phone ', 'docpro' ),
						'default' => esc_html__( 'Phone', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_contact_info_fax',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info Fax ', 'docpro' ),
						'default' => esc_html__( 'Fax', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_contact_info_email',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info E-Mail ', 'docpro' ),
						'default' => esc_html__( 'E-Mail', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_contact_info_website',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info Website ', 'docpro' ),
						'default' => esc_html__( 'Website', 'docpro' ),
					),
					array(
						'id'          => 'docpro_clinic_contact_info_social',
						'type'        => 'text',
						'title'       => esc_html__( 'Sidebar Contact Info Social ', 'docpro' ),
						'default' => esc_html__( 'Social', 'docpro' ),
						
					),
					

				)
			);


			return apply_filters( 'docpro_filters_plugin_settings_sections', $sections );
		}


		/**
		 * Print notices
		 *
		 * @param string $message
		 * @param string $type
		 * @param bool $is_dismissible
		 */
		function print_notice( $message = '', $type = 'success', $is_dismissible = true ) {

			$is_dismissible = $is_dismissible ? 'is-dismissible' : '';

			if ( ! empty( $message ) ) {
				printf( '<div class="docpro-notice notice notice-%s %s"><p>%s</p></div>', $type, $is_dismissible, $message );
			}
		}


		/**
		 * Return Post Meta Value
		 *
		 * @param bool $meta_key
		 * @param bool $post_id
		 * @param string $default
		 * @param bool $singular
		 *
		 * @return mixed|string|void
		 */
		function get_meta( $meta_key = false, $post_id = false, $default = '', $singular = true ) {

			if ( ! $meta_key ) {
				return '';
			}

			$post_id    = ! $post_id ? get_the_ID() : $post_id;
			$meta_value = get_post_meta( $post_id, $meta_key, $singular );
			$meta_value = empty( $meta_value ) ? $default : $meta_value;

			return apply_filters( 'docpro_filters_get_meta', $meta_value, $meta_key, $post_id, $default, $singular );
		}


		/**
		 * Return option value
		 *
		 * @param string $option_key
		 * @param string $default_val
		 *
		 * @return mixed|string|void
		 */
		function get_option( $option_key = '', $default_val = '' ) {

			if ( empty( $option_key ) ) {
				return '';
			}

			$docpro_settings = get_option( 'docpro_settings' );
			$option_val      = $this->get_args_option( $option_key, $default_val, $docpro_settings );
			$option_val      = is_array( $default_val ) && empty( $option_val ) ? array() : $option_val;
			$option_val      = ! is_array( $default_val ) && empty( $option_val ) ? $default_val : $option_val;

			return apply_filters( 'docpro_filters_option_' . $option_key, $option_val );
		}


		/**
		 * Return PB_Settings class
		 *
		 * @param array $args
		 *
		 * @return PB_Settings
		 */
		function PB_Settings( $args = array() ) {

			return new PB_Settings( $args );
		}


		/**
		 * Return Arguments Value
		 *
		 * @param string $key
		 * @param string $default
		 * @param array $args
		 *
		 * @return mixed|string
		 */
		function get_args_option( $key = '', $default = '', $args = array() ) {

			global $this_preloader;

			$args    = empty( $args ) ? $this_preloader : $args;
			$default = empty( $default ) ? '' : $default;
			$key     = empty( $key ) ? '' : $key;

			if ( isset( $args[ $key ] ) && ! empty( $args[ $key ] ) ) {
				return $args[ $key ];
			}

			return $default;
		}
	}
}

global $docpro;

$docpro = new DOCPRO_Functions();