<?php
// silence is golden.