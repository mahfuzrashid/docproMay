<?php
/**
 * Doctors - Items
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

?>

<p class="not-found"><?php esc_html_e( 'No doctor found!', 'docpro' ); ?></p>