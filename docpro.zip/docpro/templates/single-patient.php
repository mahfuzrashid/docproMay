<?php
/**
 * Single Patient
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="doctor-details patient-details bg-color-3">
    <div class="auto-container">
        <div class="row clearfix">
			<?php docpro_get_template( 'patient/content.php' ); ?>
        </div>
    </div>
</div>
