<?php
/**
 * Clinic Details - Nav Item Overview Section - About
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $clinic;
?>
<h3><?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_about' )) ; ?></h3>

<p><?php echo esc_html( $clinic->about ); ?></p>