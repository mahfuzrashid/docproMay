<?php
/**
 * Clinic Details - Nav Item Overview Section - Specifications
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $clinic;

?>
    <h3><?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_specialities' )) ; ?></h3>

    <p><?php echo apply_filters( 'docpro_filters_text_overview_specifications', sprintf( wp_kses( '<strong>%s</strong> ', 'docpro' ), $clinic->display_name ) ); ?> <?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_specialities2' )) ; ?></p> 

<?php if ( ! empty( $specifications = docpro_array_map( 'name', $clinic->specifications ) ) ) : ?>
    <ul class="treatments-list list clearfix">
		<?php printf( '<li>%s</li>', implode( '</li><li>', $specifications ) ); ?>
    </ul>
<?php endif; ?>