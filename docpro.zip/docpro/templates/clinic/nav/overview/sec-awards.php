<?php
/**
 * Clinic Details - Nav Item Overview Section - Awards
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $clinic;

?>
<div class="award-box">
    <h3><?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_awards' )) ; ?></h3>
	<?php if ( ! empty( $clinic->awards ) ) : ?>
        <ul class="list clearfix">
			<?php foreach ( $clinic->awards as $award ) : ?>
				<?php printf( '<li>%s <span>%s</span></li>',
					sprintf( esc_html__( ' (%s)  %s', 'docpro' ),
						docpro()->get_args_option( 'name', '', $award ),
						docpro()->get_args_option( 'organisation', '', $award )
					),
					docpro()->get_args_option( 'year', '', $award ) ); ?>
			<?php endforeach; ?>
        </ul>

	<?php endif; ?>
</div>

