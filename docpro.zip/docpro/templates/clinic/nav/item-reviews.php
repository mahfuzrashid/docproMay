<?php
/**
 * Doctor Details - Nav Item - Reviews
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $clinic;

?>

<div class="tab <?php echo esc_attr( $active_class ); ?>" id="reviews">
    <div class="review-box">
        <h3><?php printf( esc_html__( '%s ', 'docpro' ), $clinic->display_name ); ?> <?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_reviews' )) ; ?></h3>
        <div class="rating-inner">
            <div class="rating-box">
                <h2><?php echo esc_html( $clinic->get_average_review_rating() ); ?></h2>
				<?php docpro_render_rating( $clinic->get_average_review_rating() ); ?>
                <span><?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_reviews_based' )) ; ?><?php printf( esc_html__( ' %s ', 'docpro' ), $clinic->get_reviews_count() ); ?></span>
            </div>
                <div class="rating-pregress">
                <div class="single-progress">
                    <span class="porgress-bar"></span>
                    <div class="text"><p><i class="icon-Star"></i><i class="icon-Star"></i><i class="icon-Star"></i><i class="icon-Star"></i><i class="icon-Star"></i></p></div>
                </div>
                <div class="single-progress">
                    <span class="porgress-bar"></span>
                    <div class="text"><p><i class="icon-Star"></i><i class="icon-Star"></i><i class="icon-Star"></i><i class="icon-Star"></i></p></div>
                </div>
                <div class="single-progress">
                    <span class="porgress-bar"></span>
                    <div class="text"><p><i class="icon-Star"></i><i class="icon-Star"></i><i class="icon-Star"></i></p></div>
                </div>
                <div class="single-progress">
                    <span class="porgress-bar"></span>
                    <div class="text"><p><i class="icon-Star"></i><i class="icon-Star"></i></p></div>
                </div>
                <div class="single-progress">
                    <span class="porgress-bar"></span>
                    <div class="text"><p><i class="icon-Star"></i></p></div>
                </div>
            </div>
        </div>
        <div class="review-inner">
			<?php foreach ( $clinic->get_reviews() as $review ) :

				if ( ! $review || empty( $review ) ) {
					continue;
				}

				$review   = (object) $review;
				$reviewer = docpro_get_profile( '', $review->reviewer ); ?>

                <div class="single-review-box">
                    <figure class="image-box"><img src="<?php echo esc_url( $reviewer->get_avatar_url() ); ?>"></figure>
					<?php docpro_render_rating( $review->star ); ?>
					<?php printf( '<h5>%s <span>- %s</span></h5>', $reviewer->display_name, date( 'F j, Y', strtotime( $review->datetime ) ) ); ?>
					<?php printf( '<h6>%s</h6>', $review->title ); ?>
					<?php printf( '<p>%s</p>', $review->message ); ?>
                </div>
			<?php endforeach; ?>
        </div>

        <div class="btn-box">
            <a href="<?php echo esc_url( $clinic->get_review_form_url() ); ?>" class="theme-btn-one"><?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_reviews_bbtn' )) ; ?>  <i class="icon-Arrow-Right"></i></a>
        </div>
    </div>
</div>