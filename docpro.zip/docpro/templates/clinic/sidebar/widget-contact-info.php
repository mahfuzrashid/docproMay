<?php
/**
 * Clinic Details - Sidebar - Contact Info
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $clinic;

$social_profiles = is_array( $clinic->social_profiles ) ? $clinic->social_profiles : array();
$social_profiles = array_map( function ( $social_profile ) {
	return sprintf( '<li><a href="%s" title="%s"><i class="%s"></i></a></li>',
		docpro()->get_args_option( 'url', '', $social_profile ),
		docpro()->get_args_option( 'platform', '', $social_profile ),
		docpro()->get_args_option( 'icon', '', $social_profile )
	);
}, $social_profiles );


?>

<div class="info-widget">
    <div class="info-title">
        <h3><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info' )) ; ?></h3>
      
    </div>
    <div class="info-inner">
        <ul class="info-list clearfix">
            <li>
                <h4><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info_location' )) ; ?></h4>
                <p><?php echo esc_html( $clinic->get_primary_location_formatted() ); ?></p>
            </li>
            <li>
                <h4><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info_phone' )) ; ?><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info' )) ; ?></h4>
                <p><?php printf( '<a href="tel:%1$s">%1$s</a>', $clinic->phone ); ?></p>
            </li>
            <li>
                <h4><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info_fax' )) ; ?></h4>
                <p><?php printf( '<a href="tel:%1$s">%1$s</a>', $clinic->fax ); ?></p>
            </li>
            <li>
                <h4><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info_email' )) ; ?></h4>
                <p><?php printf( '<a href="mailto:%1$s">%1$s</a>', $clinic->user_email ); ?></p>
            </li>
            <li>
                <h4><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info_website' )) ; ?></h4>
                <p><?php printf( '<a href="%1$s">%1$s</a>', $clinic->user_url ); ?></p>
            </li>
        </ul>
        <div class="social-box">
            <h4><?php echo esc_html( docpro()->get_option( 'docpro_clinic_contact_info_social' )) ; ?></h4>
			<?php printf( '<ul class="social-links clearfix">%s</ul>', implode( '', $social_profiles ) ); ?>
        </div>
    </div>
</div>