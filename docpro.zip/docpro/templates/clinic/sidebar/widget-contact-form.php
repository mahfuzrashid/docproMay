<?php
/**
 * Clinic Details - Sidebar - Contact Form
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $clinic;

?>

<div class="form-widget">
    <div class="form-title">
        <h3><?php echo esc_html( docpro()->get_option( 'docpro_clinic_text_contact' )) ; ?></h3>
          <p><?php echo esc_html( $clinic->slogan ); ?></p>
    </div>
    <div class="form-inner">
		
		<?php echo do_shortcode(sprintf(  docpro()->get_option( 'docpro_clinic_contact_form7' ))) ; ?>
    </div>
</div>