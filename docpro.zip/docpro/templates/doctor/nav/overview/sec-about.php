<?php
/**
 * Doctor Details - Nav Item Overview Section - About
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $doctor;
?>
<h3><?php echo esc_html( docpro()->get_option( 'docpro_doctors_text_about' )) ; ?> <?php echo apply_filters( '', sprintf( wp_kses( ' %s ', 'docpro' ), $doctor->display_name ) ); ?></h3>

<p><?php echo esc_html( $doctor->description ); ?></p>