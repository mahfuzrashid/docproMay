<?php
/**
 * Doctor Details - Nav Item - Experiences
 *
 * @copyright docpro @2020
 */

defined( 'ABSPATH' ) || exit;

global $doctor;

?>

<div class="tab <?php echo esc_attr( $active_class ); ?>" id="experiences">
    <div class="experience-box">
        <div class="text">
            <h3><?php echo esc_html( docpro()->get_option( 'docpro_doctors_text_experience' )) ; ?></h3>

			<?php if ( ! empty( $doctor->experiences ) ) : ?>
                <ul class="experience-list list clearfix">
					<?php foreach ( $doctor->experiences as $experience ) : ?>
						<?php
						$start_date = docpro()->get_args_option( 'started', '', $experience );
						$end_date   = docpro()->get_args_option( 'end', '', $experience );

						printf( '<li>%s <span>(%s)</span> <p>%s <span>%s</span></p></li>',
							docpro()->get_args_option( 'institution', '', $experience ),
							docpro()->get_args_option( 'department', '', $experience ),
							docpro()->get_args_option( 'position', '', $experience ),
							docpro_date_range( $start_date, $end_date ) );
						?>
					<?php endforeach; ?>
                </ul>
			<?php endif; ?>

            <h3> <?php echo esc_html( docpro()->get_option( 'docpro_doctors_text_skills' )) ; ?></h3>
			<?php if ( ! empty( $doctor->skills ) ) : ?>
                <ul class="skills-list list clearfix">
					<?php foreach ( $doctor->skills as $skill ) : ?>
                        <li>
							<?php echo esc_html( docpro()->get_option( 'docpro_doctors_text_skills_in' )) ; ?><?php printf( esc_html__( ' %s ', 'docpro' ) , docpro()->get_args_option( 'name', '', $skill ) ); ?>
                        </li>
					<?php endforeach; ?>
                </ul>
			<?php endif; ?>
        </div>
    </div>
</div>